// var studentNames = [];

// var studentNames = new Array();

// var stringsArray = ["Apple", "Banana", "Mango"];

// var numbersArray = [10, 20, 30, 40];

// var booleanArray = [true, false, true, false];

// var mixedArray = ["Ali", 25, true, 3.5];

// var education = ["SSC", "HSC", "BCS", "BS", "BCOM", "MS", "M. Phil.", "PhD"];
// document.write("<h3>Qualifications</h3>");
// for (var i = 0; i < education.length; i++) {
//     document.write((i+1) + ") " + education[i] + "<br>");
// }

// var students = ["Michael", "John", "Tony"];
// var scores = [400, 350, 450];
// var totalMarks = 500;
// for (var i = 0; i < students.length; i++) {
//     var percentage = (scores[i] / totalMarks) * 100;
//     document.write(students[i] + " scored " + scores[i] + 
//     " out of " + totalMarks + " (" + percentage + "%)<br>");
// }

// var colors = ["Red", "Green", "Blue"];
// document.write(colors + "<br>");
// var addStart = prompt("Enter color to add at start:");
// colors.unshift(addStart);
// document.write(colors + "<br>");
// var addEnd = prompt("Enter color to add at end:");
// colors.push(addEnd);
// document.write(colors + "<br>");
// colors.unshift("Purple", "Yellow");
// document.write(colors + "<br>");
// colors.shift();
// document.write(colors + "<br>");
// colors.pop();
// document.write(colors + "<br>");
// var indexAdd = +prompt("At which index to add color?");
// var colorName = prompt("Enter color name:");
// colors.splice(indexAdd, 0, colorName);
// document.write(colors + "<br>");
// var indexDel = +prompt("At which index to delete color?");
// var countDel = +prompt("How many colors to delete?");
// colors.splice(indexDel, countDel);
// document.write(colors + "<br>");

// var scores = [320, 230, 480, 120];
// scores.sort();
// document.write("Scores of students: "+ scores +"<br>")
// document.write("Sorted Scores: " + scores);

// var cities = ["Karachi", "Lahore", "Islamabad", "Quetta", "Peshawar"];
// var selectedCities = cities.slice(2, 4);
// document.write("Selected Cities: " + cities +"<br>");
// document.write("Selected Cities: " + selectedCities);

// var arr = ["This", "is", "my", "cat"];
// var result = arr.join(" ");
// document.write("Array: " + arr +"<br>");
// document.write(result);

// var fifo = [];
// fifo.push("Keyboard");
// fifo.push("Mouse");
// fifo.push("Printer");
// fifo.push("Monitor");
// document.write("Devices: "+ fifo +"<br><br>");
// while(fifo.length > 0){
//     document.write("Out:<br>");
//     document.write(fifo.shift() + "<br>");
// }

// var lifo = [];
// lifo.push("Keyboard");
// lifo.push("Mouse");
// lifo.push("Printer");
// lifo.push("Monitor");
// document.write("Devices: "+ lifo +"<br><br>");
// while(lifo.length > 0){
//     document.write("Out:<br>");
//     document.write(lifo.pop() + "<br>");
// }

// var manufacturers = ["Apple", "Samsung", "Motorola", "Nokia", "Sony", "Haier"];
// document.write("<select>");
// for (var i = 0; i < manufacturers.length; i++) {
//     document.write("<option>" + manufacturers[i] + "</option>");
// }
// document.write("</select>");

// var arr1 = [[], [], []];

// var arr2 = [
//   [0, 1, 2, 3],
//   [1, 0, 1, 2],
//   [2, 1, 0, 1]
// ];

// for (var i = 0; i < arr2.length; i++) {
//   for (var j = 0; j < arr2[i].length; j++) {
//     document.write(arr2[i][j] + " ");
//   }
//   document.write("<br>");
// }

// for (var i = 1; i <= 10; i++) {
//   document.write(i + "<br>");
// }

// var tableNum = +prompt("Enter table number:");
// var tableLen = +prompt("Enter table length:");
// for (var i = 1; i <= tableLen; i++) {
//   document.write(tableNum + " x " + i + " = " + (tableNum * i) + "<br>");
// }

// var fruits = ["apple", "banana", "mango", "orange", "strawberry"];

// for (var i = 0; i < fruits.length; i++) {
//     document.write( fruits[i] + "<br>");
// }
    
//     document.write("<br>");

// for (var i = 0; i < fruits.length; i++) {
//     document.write("Element at index " + i + " is " + fruits[i] + "<br>");
// }

// document.write("<h3>Counting:</h3>");
// for (var i = 1; i <= 15; i++) {
//   document.write(i + ", ");
// }
// document.write("<h3>Reverse Counting:</h3>");
// for (var i = 10; i >= 1; i--) {
//   document.write(i + ", ");
// }
// document.write("<h3>Even:</h3>");
// for (var i = 0; i <= 20; i += 2) {
//   document.write(i + ", ");
// }
// document.write("<h3>Odd:</h3>");
// for (var i = 1; i < 20; i += 2) {
//   document.write(i + ", ");
// }
// document.write("<h3>Series:</h3>");
// for (var i = 2; i <= 20; i += 2) {
//   document.write(i + "k, ");
// }

// var A = ["cake", "apple pie", "cookie", "chips", "patties"];
// var userInput = prompt("Welcome to ABC Bakery. What do you want to order?");
// var found = false;
// var index = -1;

// for (var i = 0; i < A.length; i++) {
//   if (A[i].toLowerCase() === userInput.toLowerCase()) {
//     found = true;
//     index = i;
//     break;
//   }
// }

// if (found) {
//   document.write(userInput + " is available at index " + index + " in our bakery");
// } else {
//   document.write("We are sorry. " + userInput + " is not available in our bakery");
// }

// var A = [24, 53, 78, 91, 12];
// var largest = A[0];
// for (var i = 1; i < A.length; i++) {
//   if (A[i] > largest) {
//     largest = A[i];
//   }
// }
//     document.write("Largest number is " + largest);

// var A = [24, 53, 78, 91, 12];
// var smallest = A[0];
// for (var i = 1; i < A.length; i++) {
//   if (A[i] < smallest) {
//     smallest = A[i];
//   }
// }
// document.write("Smallest number is " + smallest);

// document.write("<h3>Multiples of 5:</h3>");
// for (var i = 5; i <= 100; i += 5) {
//   document.write(i + ", ");
// }
