// function currentDateTime() {
//   return new Date();
// }
//  document.write("Date & Time: "+currentDateTime());

// function greet(firstName, lastName) {
//   return 'Hello ' + firstName + ' ' + lastName;
// }
//     document.write(greet("Anis ","Ur Rehman"));

// function addNumbers(a, b) {
//   return a + b;
// }
//     document.write(addNumbers(5,10));

// function calculator(a, b, op) {
//   if (op === '+') return a + b;
//   if (op === '-') return a - b;
//   if (op === '*') return a * b;
//   if (op === '/') return a / b;
//   if (op === '%') return a % b;
//   return null;
// }
//     document.write(calculator(10,5,'/'));

// function square(n) {
//   return n * n;
// }
//     document.write("Square: "+square(10));

// function factorial(n) {
//   let f = 1;
//   for (let i = 2; i <= n; i++) f *= i;
//   return f;
// }
//     document.write(factorial(5));

// function counting(start, end) {
//   var arr = [];
//   if (start <= end) {
//     for (var i = start; i <= end; i++) arr.push(i);
//   } else {
//     for (var i = start; i >= end; i--) arr.push(i);
//   }
//   return arr;
// }
//     document.write(counting(1,10));

// function hypotenuse(base, perp) {
//   function square(x) {
//     return x * x;
//   }
//   return Math.sqrt(square(base) + square(perp));
// }
//     document.write('Hypotenuse 3,4: ', hypotenuse(3, 4));

// function areaRectangle(width, height) {
//   return width * height;
// }
//     document.write(areaRectangle(10,5));

// function isPalindrome(str) {
//   str = str.toLowerCase();
//   return str === str.split('').reverse().join('');
// }
// document.write('Palindrome: ', isPalindrome('racecar'));

// function toTitleCase(str) {
//   return str.toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
// }
//     document.write((toTitleCase('the quick brown fox')));

// function longestWord(str) {
//   let words = str.split(' ');
//   return words.reduce((a, b) => (b.length > a.length ? b : a));
// }
//     document.write(longestWord("Web Development Tutorial"));

// function countChar(str, ch) {
//   str = str.toLowerCase();
//   ch = ch.toLowerCase();
//   var count = 0;
//   for (var c of str) if (c === ch) count++;
//   return count;
// }
//     document.write(('Count of e in "Cheese":', countChar('Cheese', 'e')));

// function circleCircumference(r) {
//   return 2 * Math.PI * r;
// }
// function circleArea(r) {
//   return Math.PI * r * r;
// }
// document.write('Circle circumference: ', circleCircumference(5).toFixed(2));

// function power(a, b) {
//     return a ** b;
// }
// document.write("Power= " + power(5, 3));

// function isLeapYear(year) {
//     if ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) {
//         return "Leap Year";
//     } else {
//         return "Not a Leap Year";
//     }
// }
// document.write("2025 is " + isLeapYear(2025));

// function semiPerimeter(a, b, c) {
//     return (a + b + c) / 2;
// }
// function areaOfTriangle(a, b, c) {
//     var s = semiPerimeter(a, b, c);
//     return Math.sqrt(s * (s - a) * (s - b) * (s - c));
// }
// document.write("Area of triangle (3,4,5) = " + areaOfTriangle(3, 4, 5) + "<br><br>");

// function average(m1, m2, m3) {
//     return (m1 + m2 + m3) / 3;
// }
// function percentage(m1, m2, m3) {
//     var total = m1 + m2 + m3;
//     return (total / 300) * 100;
// }
// function mainFunction(m1, m2, m3) {
//     document.write("Average: " + average(m1, m2, m3) + "<br>");
//     document.write("Percentage: " + percentage(m1, m2, m3) + "%");
// }

// mainFunction(80, 70, 90);

// function customIndexOf(str, char) {
//     for (var i = 0; i < str.length; i++) {
//         if (str[i] === char) {
//             return i;
//         }
//     }
//     return;
// }
// document.write("Index of 'e' in 'Cheese' = " + customIndexOf("Cheese", "e"));

// function removeVowels(sentence) {
//     return sentence.replace(/[aeiouAEIOU]/g, "");
// }
// document.write("Without vowels: " + removeVowels("This is a sentence"));

// function countDoubleVowels(text) {
//     var count = 0;
//     for (var i = 0; i < text.length - 1; i++) {
//         var pair = text[i].toLowerCase() + text[i + 1].toLowerCase();
//         switch (pair) {
//             case "aa": case "ae": case "ai": case "ao": case "au":
//             case "ea": case "ee": case "ei": case "eo": case "eu":
//             case "ia": case "ie": case "ii": case "io": case "iu":
//             case "oa": case "oe": case "oi": case "oo": case "ou":
//             case "ua": case "ue": case "ui": case "uo": case "uu":
//                 count++;
//                 break;
//         }
//     }
//     return count;
// }
// document.write("Occurrences = " + countDoubleVowels("Pleases read this application and give me gratuity") + "<br><br>");

// function toMeters(km) {
//     return km * 1000;
// }
// function toFeet(km) {
//     return km * 3280.84;
// }
// function toInches(km) {
//     return km * 39370.1;
// }
// function toCentimeters(km) {
//     return km * 100000;
// }
// var distance = 5;
// document.write(distance + " km = " + toMeters(distance) + " meters<br>");
// document.write(distance + " km = " + toFeet(distance) + " feet<br>");
// document.write(distance + " km = " + toInches(distance) + " inches<br>");
// document.write(distance + " km = " + toCentimeters(distance) + " cm<br><br>");

// function overtimePay(hoursWorked) {
//     if (hoursWorked > 40) {
//         return (hoursWorked - 40) * 12;
//     } else {
//         return 0;
//     }
// }
// document.write("Overtime pay for 45 hours = Rs. " + overtimePay(45));

// function currencyNotes(amount) {
//     var hundreds = Math.floor(amount / 100);
//     var fifty = Math.floor((amount % 100) / 50);
//     var ten = Math.floor(((amount % 100) % 50) / 10);
//     document.write("100 notes: " + hundreds + "<br>");
//     document.write("50 notes: " + fifty + "<br>");
//     document.write("10 notes: " + ten + "<br>");
// }
// currencyNotes(870);

// function showAlert() {
//     alert("Link clicked!");
// }

// function mobileAlert(){
//     alert("Thanks for purchasing mobile from us");
// }

// function deleteRow(btn) {
//     var row = btn.parentNode.parentNode;
//     row.parentNode.removeChild(row);
// }

function changeImage() {
    document.getElementById("changeImg").src = "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1200&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8Y2FyfGVufDB8fDB8fHww";
}

function resetImage() {
    document.getElementById("changeImg").src = "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=1200&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fHww";
}

var count = 0;
function increase() {
    count++;
    document.getElementById("counter").innerHTML = count;
}
function decrease() {
    count--;
    document.getElementById("counter").innerHTML = count;
}
