// document.write(new Date());

// var monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
// alert(monthNames[new Date().getMonth()]);

// var dayNames = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
// alert(dayNames[new Date().getDay()]);

// var day = new Date().getDay();
// if (day === 0 || day === 6) {
//   alert("It's Fun day");
// } else {
//   alert("It's not Fun day. Today is day " + day);
// }

// var date = new Date().getDate();
// if (date < 16) {
//   alert("First fifteen days of the month");
// } else {
//   alert("Last days of the month");
// }

// var ms = new Date().getTime();
// var ms = ms / (1000 * 60);
// alert("Minutes since Jan 1, 1970: " + ms);

// var hours = new Date().getHours();
// alert((hours < 12 ? "Its AM" : "Its PM"));

// var laterDate = new Date(2020, 11, 31);
// document.write(laterDate);

// var ramadanStart = new Date("June 18, 2015");
// var todayDate = new Date();
// var diffDays = Math.floor((todayDate - ramadanStart) / (1000 * 60 * 60 * 24));
// alert("Days since 1st Ramadan 2015: " + diffDays);

// var refDate = new Date(); 
// var begin2015 = new Date("Jan 1, 2015");
// var secondsElapsed = Math.floor((refDate - begin2015) / 1000);
// document.write("<h3>Seconds since 2015:</h3>" + secondsElapsed);

// var currentDate = new Date();
// currentDate.setHours(currentDate.getHours() + 1);
// document.write("<h3>Date after 1 hour:</h3>" + currentDate);

// var dateBack = new Date();
// dateBack.setFullYear(dateBack.getFullYear() - 100);
// alert("Date 100 years back: " + dateBack);

// var age = prompt("Enter your age:");
// var birthYear = new Date().getFullYear() - age;
// document.write("<h3>Your birth year:</h3>" + birthYear);

// var monthNames = ["January","February","March","April","May","June",
// "July","August","September","October","November","December"];

// var customerName = "ABC Customer";
// var currentMonth = monthNames[new Date().getMonth()];
// var numberOfUnits = 410;
// var chargesPerUnit = 16;
// var latePaymentSurcharge = 350;

// var netAmount = (numberOfUnits * chargesPerUnit).toFixed(2);
// var grossAmount = (parseFloat(netAmount) + latePaymentSurcharge).toFixed(2);

// document.write("<h3>K-Electric Bill</h3>");
// document.write("Customer Name: " + customerName + "<br>");
// document.write("Month: " + currentMonth + "<br>");
// document.write("Number of units: " + numberOfUnits + "<br>");
// document.write("Charges per unit: " + chargesPerUnit + "<br>");
// document.write("Net Amount Payable (within Due Date): " + netAmount + "<br>");
// document.write("Late Payment Surcharge: " + latePaymentSurcharge + "<br>");
// document.write("Gross Amount Payable (after Due Date): " + grossAmount + "<br>");